angular.module('ionicApp', ['ionic'])

.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('app', {
      url: "/app",
      abstract: true,
      templateUrl: "menu.html"
    })
    .state('app.User', {
      url: "/User",
      views: {
        'menuContent' :{
          templateUrl: "User.html",
		  controller: "UserCtrl"
        }
      }
    })
  .state('app.playlist', {
      url: "/User/:playlistId",
      views: {
        'menuContent' :{
          templateUrl: "playlist.html",
		  controller: "PlaylistCtrl"
        }
      }
    })
    .state('app.my', {
      url: "/my",
      views: {
        'menuContent' :{
          templateUrl: "my.html",
          controller: "MyCtrl"
        }
      }
    })
  
  $urlRouterProvider.otherwise("/app/User");
})

.controller('UserCtrl', function($scope,$rootScope) {
  $rootScope.User = [
    { title: 'SUCHISMITA', ltitle: 'ROUT', photo: 'avatar', country: 'INDIA', city: 'BHUBANESWAR', age: '18', desc: 'FULL STACK DEVELOPER', gender: 'FEMALE', id: 0 },
    { title: 'SOUMYADEEP', ltitle: 'NAYAK', photo: 'avatar', country: 'INDIA', city: 'BHUBANESWAR', age: '20', desc: 'WEB DEGINER, GAMER', gender: 'MALE', id: 1 },
    { title: 'SATYAM', ltitle: 'KUMAR', photo: 'avatar', country: 'INDIA', city: 'BHUBANESWAR', age: '19', desc: 'Web Developer', gender: 'MALE', id: 2 },
    { title: 'EKALABYA', ltitle: 'BEHERA', photo: 'avatar', country: 'INDIA', city: 'CUTTACK', age: '20', desc: 'Web Developer', gender: 'MALE', id: 3 },
    { title: 'SK', ltitle: '', photo: 'avatar', country: 'INDIA', city: 'BHUBANESWAR', age: '19', desc: 'Web Developer', gender: 'MALE', id: 4 },
    { title: 'ROSAN', ltitle: 'KUMAR', photo: 'avatar', country: 'INDIA', city: 'BHUBANESWAR', age: '20', desc: 'Web Developer', gender: 'MALE', id: 5 }
  ];
})

.controller('PlaylistCtrl', function($scope,$stateParams,$rootScope) {
  $scope.gelenid=$stateParams.playlistId;
  $scope.title=$rootScope.User[$scope.gelenid].title;
  $scope.ltitle=$rootScope.User[$scope.gelenid].ltitle;
  $scope.gender=$rootScope.User[$scope.gelenid].gender;
  $scope.desc=$rootScope.User[$scope.gelenid].desc;
  $scope.age=$rootScope.User[$scope.gelenid].age;
  $scope.photo=$rootScope.User[$scope.gelenid].photo;
  $scope.country=$rootScope.User[$scope.gelenid].country;
  $scope.city=$rootScope.User[$scope.gelenid].city;
})


.controller('MainCtrl', function($scope, $ionicSideMenuDelegate) {
  $scope.toggleLeft = function() {
    $ionicSideMenuDelegate.toggleLeft();
  };
})
$scope.$on('$ionicView.beforeEnter', function (event) {
$scope.$root.showMenuIcon = false;
$ionicSideMenuDelegate.canDragContent(false);
});

$scope.$on('$ionicView.beforeLeave', function (event) {
  $scope.$root.showMenuIcon = true;
  $ionicSideMenuDelegate.canDragContent(true);
});